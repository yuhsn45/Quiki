/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'brand-purple': '#6C5CE7',
        'brand-gold': '#FFD700',
        'brand-cream': '#FFF8E7',
        'brand-charcoal': '#2D3436',
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'], // Using Inter as a safe web font
      }
    },
  },
  plugins: [],
}
