import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, Gift, Calendar, Heart } from 'lucide-react';

const OnboardingScreen = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [name, setName] = useState('');
  
  const handleNext = () => {
    if (step < 3) {
      setStep(step + 1);
    } else {
      navigate('/home');
    }
  };

  const steps = [
    {
      title: "Hi there! 👋",
      subtitle: "I'm your celebration assistant. What should I call you?",
      component: (
        <input 
          type="text" 
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Enter your name"
          className="w-full bg-brand-cream/50 p-4 rounded-xl text-xl font-bold text-brand-charcoal outline-none border-2 border-transparent focus:border-brand-purple transition-all"
        />
      )
    },
    {
      title: "Who do you spoil? 🎁",
      subtitle: "Tell us who you celebrate with most often.",
      component: (
        <div className="space-y-3">
          {['Partner', 'Parents', 'Best Friend', 'Myself'].map((item) => (
            <button key={item} className="w-full bg-white p-4 rounded-xl shadow-sm text-left font-bold text-gray-700 hover:bg-brand-purple hover:text-white transition-colors flex justify-between items-center group">
              {item}
              <Heart size={18} className="text-gray-300 group-hover:text-white" />
            </button>
          ))}
        </div>
      )
    },
    {
      title: "Flavor Profile 🍰",
      subtitle: "What kind of cakes make you melt?",
      component: (
        <div className="grid grid-cols-2 gap-3">
          {['Chocolate', 'Fruit', 'Cream', 'Exotic'].map((item) => (
            <button key={item} className="bg-white p-4 rounded-xl shadow-sm font-bold text-gray-700 hover:bg-brand-gold hover:text-brand-charcoal transition-colors">
              {item}
            </button>
          ))}
        </div>
      )
    },
    {
      title: "Important Dates 📅",
      subtitle: "Never forget a birthday again. Sync your calendar?",
      component: (
        <div className="space-y-4">
          <div className="bg-white p-6 rounded-2xl shadow-sm flex flex-col items-center justify-center border-2 border-dashed border-gray-300">
            <Calendar size={48} className="text-brand-purple mb-2" />
            <p className="font-bold text-gray-600">Sync with Calendar</p>
          </div>
          <button onClick={handleNext} className="w-full text-center text-gray-400 font-bold text-sm">Skip for now</button>
        </div>
      )
    }
  ];

  return (
    <div className="h-screen bg-gray-50 flex flex-col p-8 relative overflow-hidden">
      {/* Progress */}
      <div className="flex space-x-2 mb-12">
        {[0, 1, 2, 3].map((i) => (
          <div key={i} className={`h-1.5 flex-1 rounded-full transition-colors duration-300 ${i <= step ? 'bg-brand-purple' : 'bg-gray-200'}`} />
        ))}
      </div>

      <motion.div
        key={step}
        initial={{ x: 50, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        exit={{ x: -50, opacity: 0 }}
        className="flex-1"
      >
        <div className="w-16 h-16 bg-white rounded-2xl shadow-lg flex items-center justify-center mb-8">
           <span className="text-3xl">✨</span>
        </div>
        
        <h1 className="text-3xl font-bold text-brand-charcoal mb-3">{steps[step].title}</h1>
        <p className="text-gray-500 text-lg mb-8">{steps[step].subtitle}</p>
        
        {steps[step].component}
      </motion.div>

      <button 
        onClick={handleNext}
        className="w-full bg-brand-purple text-white py-4 rounded-2xl font-bold text-lg shadow-lg shadow-brand-purple/30 flex justify-center items-center mt-auto"
      >
        <span>{step === 3 ? "Get Started" : "Next"}</span>
        <ArrowRight className="ml-2" />
      </button>
    </div>
  );
};

export default OnboardingScreen;
