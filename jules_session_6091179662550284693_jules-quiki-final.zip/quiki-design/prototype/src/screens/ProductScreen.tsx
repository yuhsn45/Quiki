import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, Star, Clock, Heart, PlayCircle, Box, Mic } from 'lucide-react';

const ProductScreen = () => {
  const navigate = useNavigate();
  const [arMode, setArMode] = useState(false);

  return (
    <motion.div 
      initial={{ x: "100%" }} 
      animate={{ x: 0 }} 
      exit={{ x: "100%" }}
      className="bg-white min-h-screen pb-24 relative"
    >
      {/* Header */}
      <div className="absolute top-0 left-0 right-0 p-6 flex justify-between items-center z-20">
        <button onClick={() => navigate(-1)} className="bg-white/80 backdrop-blur-md p-2 rounded-xl shadow-sm">
          <ChevronLeft size={24} className="text-gray-800" />
        </button>
        <button className="bg-white/80 backdrop-blur-md p-2 rounded-xl shadow-sm">
          <Heart size={24} className="text-gray-800" />
        </button>
      </div>

      {/* Image / AR View */}
      <div className="h-[45vh] bg-gray-100 relative">
        {arMode ? (
          <div className="w-full h-full bg-black/90 flex flex-col items-center justify-center text-white">
            <Box size={48} className="text-brand-gold animate-bounce mb-4" />
            <p>AR View Active</p>
            <p className="text-xs text-gray-400">Point camera at table</p>
          </div>
        ) : (
          <img 
            src="https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&q=80&w=600" 
            alt="Cake" 
            className="w-full h-full object-cover"
          />
        )}
        
        {/* AR Toggle */}
        <button 
          onClick={() => setArMode(!arMode)}
          className="absolute bottom-6 right-6 bg-white/90 backdrop-blur-md px-4 py-2 rounded-full shadow-lg flex items-center space-x-2"
        >
          <Box size={18} className="text-brand-purple" />
          <span className="text-xs font-bold text-brand-purple">View in 3D</span>
        </button>
      </div>

      {/* Content */}
      <div className="bg-white -mt-6 relative rounded-t-3xl p-6 shadow-[0_-10px_40px_rgba(0,0,0,0.05)]">
        <div className="flex justify-between items-start mb-2">
          <div>
            <h1 className="text-2xl font-bold text-gray-800 mb-1">Royal Chocolate Truffle</h1>
            <div className="flex items-center space-x-4 text-xs text-gray-500 font-medium">
              <span className="flex items-center"><Clock size={14} className="mr-1" /> 15 min</span>
              <span className="flex items-center"><Star size={14} className="mr-1 text-brand-gold" /> 4.9 (2.1k)</span>
              <span>500g</span>
            </div>
          </div>
          <div className="text-2xl font-bold text-brand-purple">₹899</div>
        </div>

        <hr className="border-gray-100 my-6" />

        {/* Story/Video */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-gray-800">Unboxing Story</h3>
            <span className="text-brand-purple text-xs font-bold">Watch</span>
          </div>
          <div className="flex space-x-3 overflow-x-auto pb-2">
            {[1, 2, 3].map((i) => (
              <div key={i} className="min-w-[100px] h-32 bg-gray-200 rounded-xl relative overflow-hidden flex-shrink-0">
                <div className="absolute inset-0 flex items-center justify-center bg-black/20">
                  <PlayCircle className="text-white" />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Personalization */}
        <div className="mb-24">
          <h3 className="font-bold text-gray-800 mb-3">Make it Special</h3>
          <div className="bg-brand-cream/50 p-4 rounded-xl border border-brand-gold/20 flex items-center justify-between mb-3">
            <div className="flex items-center">
              <div className="bg-white p-2 rounded-full mr-3 shadow-sm">
                <Mic size={20} className="text-brand-purple" />
              </div>
              <div>
                <p className="text-sm font-bold text-gray-800">Add Voice Message</p>
                <p className="text-xs text-gray-500">QR code will be on the box</p>
              </div>
            </div>
            <div className="w-6 h-6 rounded-full border-2 border-brand-purple"></div>
          </div>
        </div>
      </div>

      {/* Floating Action Button */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 p-6 pt-4 pb-8 z-30">
        <button 
          onClick={() => navigate('/cart')}
          className="w-full bg-brand-purple text-white py-4 rounded-2xl font-bold text-lg shadow-lg shadow-brand-purple/30 flex justify-between px-6 items-center"
        >
          <span>1 Item | ₹899</span>
          <span className="flex items-center">Add to Cart <ChevronLeft className="rotate-180 ml-2" /></span>
        </button>
      </div>
    </motion.div>
  );
};

export default ProductScreen;
