import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { MapPin, Bell, Star, Clock, ArrowRight } from 'lucide-react';

const HomeScreen = () => {
  const navigate = useNavigate();

  const categories = [
    { name: "Birthdays", emoji: "🎂", color: "bg-pink-100" },
    { name: "Romantic", emoji: "🌹", color: "bg-red-100" },
    { name: "Gifts", emoji: "🎁", color: "bg-blue-100" },
    { name: "Apology", emoji: "🥺", color: "bg-purple-100" },
  ];

  const featuredCakes = [
    { id: 1, name: "Royal Truffle", price: "₹899", time: "15 min", img: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&q=80&w=300" },
    { id: 2, name: "Golden Velvet", price: "₹1200", time: "20 min", img: "https://images.unsplash.com/photo-1563729768601-d65d487295d1?auto=format&fit=crop&q=80&w=300" },
  ];

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      className="pb-24 bg-gray-50 min-h-screen"
    >
      {/* Header */}
      <div className="bg-white p-6 pb-4 rounded-b-3xl shadow-sm">
        <div className="flex justify-between items-center mb-4">
          <div>
            <p className="text-gray-400 text-xs font-medium uppercase tracking-wider">Delivering to</p>
            <div className="flex items-center text-brand-charcoal font-bold">
              <MapPin size={16} className="text-brand-purple mr-1" />
              Home, Indiranagar <span className="ml-1 text-gray-300">▼</span>
            </div>
          </div>
          <div className="bg-gray-100 p-2 rounded-full relative">
            <Bell size={20} className="text-gray-600" />
            <div className="absolute top-0 right-0 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white"></div>
          </div>
        </div>
        
        {/* Search Dummy */}
        <div className="bg-gray-100 p-3 rounded-xl text-gray-400 text-sm flex items-center">
          <span className="mr-2">🔍</span> Try "Gluten Free Chocolate Cake"
        </div>
      </div>

      {/* Hero Banner - AI Personalized */}
      <div className="p-6 pt-4">
        <div className="bg-brand-purple rounded-2xl p-6 text-white relative overflow-hidden shadow-lg mb-6">
          <div className="relative z-10">
            <p className="text-brand-gold text-xs font-bold mb-1">AI REMINDER</p>
            <h2 className="text-2xl font-bold mb-2">Mom's Birthday?</h2>
            <p className="text-sm opacity-90 mb-4">It's in 2 days. Pre-order her favorite Pineapple Cake now.</p>
            <button className="bg-white text-brand-purple px-4 py-2 rounded-lg text-sm font-bold shadow-md">
              View Suggestions
            </button>
          </div>
          <div className="absolute right-0 bottom-0 w-32 h-32 bg-white/10 rounded-full blur-2xl -mr-10 -mb-10"></div>
        </div>

        {/* Categories */}
        <div className="flex justify-between gap-4 overflow-x-auto pb-2 scrollbar-hide">
          {categories.map((cat, i) => (
            <motion.div 
              key={i}
              whileTap={{ scale: 0.95 }}
              className="flex flex-col items-center min-w-[70px]"
            >
              <div className={`${cat.color} w-16 h-16 rounded-2xl flex items-center justify-center text-2xl mb-2 shadow-sm`}>
                {cat.emoji}
              </div>
              <span className="text-xs font-medium text-gray-600">{cat.name}</span>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Quick Delivery Zone */}
      <div className="px-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-bold text-brand-charcoal">Quick Delivery ⚡</h3>
          <span className="text-brand-purple text-xs font-bold">See All</span>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          {featuredCakes.map((cake) => (
            <motion.div 
              key={cake.id}
              whileTap={{ scale: 0.98 }}
              onClick={() => navigate(`/product/${cake.id}`)}
              className="bg-white rounded-2xl p-3 shadow-sm border border-gray-100"
            >
              <div className="relative mb-3 h-32 rounded-xl overflow-hidden bg-gray-200">
                <img src={cake.img} alt={cake.name} className="w-full h-full object-cover" />
                <div className="absolute top-2 left-2 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-lg text-[10px] font-bold flex items-center">
                  <Clock size={10} className="mr-1" /> {cake.time}
                </div>
              </div>
              <h4 className="font-bold text-gray-800 text-sm mb-1">{cake.name}</h4>
              <div className="flex justify-between items-center">
                <span className="text-brand-purple font-bold text-sm">{cake.price}</span>
                <div className="bg-brand-cream text-brand-purple p-1.5 rounded-lg">
                  <ArrowRight size={14} />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  );
};

export default HomeScreen;
