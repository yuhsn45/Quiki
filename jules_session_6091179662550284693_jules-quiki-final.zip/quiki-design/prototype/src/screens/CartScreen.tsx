import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, Gift, MapPin } from 'lucide-react';

const CartScreen = () => {
  const navigate = useNavigate();

  return (
    <motion.div 
      initial={{ y: "100%" }} 
      animate={{ y: 0 }} 
      exit={{ y: "100%" }}
      className="bg-gray-50 min-h-screen pb-32"
    >
      {/* Header */}
      <div className="bg-white p-6 pb-4 sticky top-0 z-10 shadow-sm">
        <div className="flex items-center space-x-4 mb-4">
          <button onClick={() => navigate(-1)} className="p-2 -ml-2">
            <ChevronLeft className="text-gray-800" />
          </button>
          <h1 className="text-xl font-bold text-gray-800">Your Cart</h1>
        </div>
        
        {/* Gamification Bar */}
        <div className="bg-brand-cream rounded-xl p-3 flex items-center space-x-3">
          <div className="bg-brand-gold/20 p-2 rounded-lg">
            <Gift size={20} className="text-brand-purple" />
          </div>
          <div className="flex-1">
            <p className="text-xs font-bold text-brand-purple mb-1">Add ₹101 more for a free gift!</p>
            <div className="h-1.5 bg-gray-200 rounded-full overflow-hidden">
              <div className="h-full w-[80%] bg-brand-purple rounded-full"></div>
            </div>
          </div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Items */}
        <div className="bg-white p-4 rounded-2xl shadow-sm">
          <div className="flex space-x-4">
            <div className="w-20 h-20 bg-gray-100 rounded-xl overflow-hidden">
              <img src="https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&q=80&w=300" className="w-full h-full object-cover" />
            </div>
            <div className="flex-1">
              <div className="flex justify-between items-start mb-1">
                <h3 className="font-bold text-gray-800 text-sm">Royal Chocolate Truffle</h3>
                <span className="font-bold text-gray-800 text-sm">₹899</span>
              </div>
              <p className="text-xs text-gray-500 mb-2">Eggless • 500g</p>
              <div className="inline-flex bg-gray-50 rounded-lg p-1 items-center space-x-3 border border-gray-100">
                <button className="w-6 h-6 flex items-center justify-center text-gray-500 font-bold">-</button>
                <span className="text-sm font-bold text-gray-800">1</span>
                <button className="w-6 h-6 flex items-center justify-center text-brand-purple font-bold">+</button>
              </div>
            </div>
          </div>
        </div>

        {/* AI Suggestion */}
        <div>
          <h3 className="text-sm font-bold text-gray-600 mb-3">Frequently bought together</h3>
          <div className="flex space-x-3 overflow-x-auto pb-2">
            <div className="min-w-[140px] bg-white p-3 rounded-xl border border-gray-100">
              <div className="h-20 bg-gray-100 rounded-lg mb-2 overflow-hidden">
                 <img src="https://images.unsplash.com/photo-1602018804364-a63459c25f48?auto=format&fit=crop&q=80&w=200" className="w-full h-full object-cover" />
              </div>
              <p className="font-bold text-xs mb-1">Gold Candles</p>
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-brand-purple">₹149</span>
                <button className="text-brand-purple text-xs font-bold bg-brand-cream px-2 py-1 rounded-md">+</button>
              </div>
            </div>
          </div>
        </div>

        {/* Bill Details */}
        <div className="bg-white p-4 rounded-2xl shadow-sm space-y-3">
          <h3 className="font-bold text-sm text-gray-800">Bill Summary</h3>
          <div className="flex justify-between text-sm text-gray-500">
            <span>Item Total</span>
            <span>₹899</span>
          </div>
          <div className="flex justify-between text-sm text-gray-500">
            <span>Delivery Fee</span>
            <span className="text-brand-purple font-bold">FREE</span>
          </div>
          <div className="flex justify-between text-sm text-gray-500">
            <span>Taxes</span>
            <span>₹45</span>
          </div>
          <hr className="border-dashed border-gray-200" />
          <div className="flex justify-between text-base font-bold text-gray-800">
            <span>To Pay</span>
            <span>₹944</span>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 p-6 pt-4 pb-8 z-30">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center text-xs text-gray-500">
            <MapPin size={14} className="mr-1" /> Delivering to Home
          </div>
          <span className="text-xs font-bold text-brand-purple">Change</span>
        </div>
        <button 
          onClick={() => navigate('/tracking')}
          className="w-full bg-brand-charcoal text-white py-4 rounded-2xl font-bold text-lg shadow-lg flex justify-center items-center relative overflow-hidden"
        >
          <span className="relative z-10">Slide to Pay ₹944</span>
          <div className="absolute left-0 top-0 bottom-0 bg-brand-gold w-16 opacity-20"></div>
        </button>
      </div>
    </motion.div>
  );
};

export default CartScreen;
