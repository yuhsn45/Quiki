import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, Phone, MessageSquare } from 'lucide-react';
import confetti from 'canvas-confetti';

const TrackingScreen = () => {
  const navigate = useNavigate();
  const [status, setStatus] = useState(0);

  useEffect(() => {
    // Simulate status updates
    const timers = [
      setTimeout(() => setStatus(1), 2000), // Packed
      setTimeout(() => setStatus(2), 5000), // On way
      setTimeout(() => {
        setStatus(3);
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#6C5CE7', '#FFD700', '#FFF8E7']
        });
      }, 10000), // Delivered
    ];
    return () => timers.forEach(clearTimeout);
  }, []);

  const steps = [
    { title: "Order Placed", time: "5:00 PM" },
    { title: "Being Packed", time: "5:02 PM" },
    { title: "On the Way", time: "5:05 PM" },
    { title: "Delivered", time: "5:18 PM" },
  ];

  return (
    <div className="bg-gray-50 min-h-screen relative flex flex-col">
      {/* Map Background (Simulated) */}
      <div className="flex-1 bg-gray-200 relative overflow-hidden">
        <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'radial-gradient(#6C5CE7 1px, transparent 1px)', backgroundSize: '20px 20px' }}></div>
        
        {/* Route Animation */}
        <svg className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 overflow-visible">
          <path 
            d="M10,10 C50,100 150,50 200,200" 
            fill="none" 
            stroke="#6C5CE7" 
            strokeWidth="4" 
            strokeDasharray="10 5"
            className="animate-pulse"
          />
          {status === 2 && (
            <motion.circle 
              cx="0" cy="0" r="8" fill="#FFD700"
              animate={{ pathLength: 1 }}
              style={{ offsetPath: 'path("M10,10 C50,100 150,50 200,200")', offsetDistance: "50%" }}
            />
          )}
        </svg>

        {/* Back Button */}
        <button onClick={() => navigate('/home')} className="absolute top-6 left-6 bg-white p-2 rounded-full shadow-lg z-10">
          <ChevronLeft size={24} />
        </button>
      </div>

      {/* Bottom Sheet */}
      <motion.div 
        initial={{ y: 100 }}
        animate={{ y: 0 }}
        className="bg-white rounded-t-3xl shadow-[0_-10px_40px_rgba(0,0,0,0.1)] p-6 pb-8"
      >
        <div className="w-12 h-1 bg-gray-200 rounded-full mx-auto mb-6"></div>

        <div className="flex justify-between items-center mb-6">
          <div>
            <h2 className="text-xl font-bold text-gray-800">
              {status === 3 ? "Arrived!" : "Arriving in 12 mins"}
            </h2>
            <p className="text-sm text-gray-500">On time | 5:18 PM</p>
          </div>
          <div className="bg-brand-purple/10 p-3 rounded-full">
            <motion.div
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ repeat: Infinity, duration: 2 }}
              className="w-8 h-8 rounded-full bg-brand-purple flex items-center justify-center text-white font-bold"
            >
              Q
            </motion.div>
          </div>
        </div>

        {/* Progress */}
        <div className="relative pl-4 border-l-2 border-gray-100 space-y-8 mb-8">
          {steps.map((step, i) => (
            <div key={i} className="relative">
              <div className={`absolute -left-[21px] top-1 w-3 h-3 rounded-full border-2 border-white shadow-sm ${i <= status ? 'bg-brand-purple' : 'bg-gray-300'}`}></div>
              <p className={`text-sm font-bold ${i <= status ? 'text-gray-800' : 'text-gray-400'}`}>{step.title}</p>
              {i === status && (
                <motion.p 
                  initial={{ opacity: 0 }} 
                  animate={{ opacity: 1 }} 
                  className="text-xs text-brand-purple mt-1"
                >
                  {i === 1 ? "Putting the cherry on top..." : i === 2 ? "Driving safely..." : i === 3 ? "Enjoy your celebration!" : ""}
                </motion.p>
              )}
            </div>
          ))}
        </div>

        {/* Driver Card */}
        <div className="flex items-center justify-between bg-gray-50 p-4 rounded-xl">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gray-300 rounded-full"></div>
            <div>
              <p className="font-bold text-sm text-gray-800">Raju K.</p>
              <p className="text-xs text-gray-500">Quiki Partner</p>
            </div>
          </div>
          <div className="flex space-x-3">
            <button className="bg-white p-2 rounded-full shadow-sm text-brand-purple"><MessageSquare size={20} /></button>
            <button className="bg-brand-purple p-2 rounded-full shadow-sm text-white"><Phone size={20} /></button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default TrackingScreen;
