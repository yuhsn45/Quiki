import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Home, Search, ShoppingBag, User } from 'lucide-react';

const BottomNav = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="absolute bottom-0 left-0 right-0 bg-white border-t border-gray-100 px-6 py-4 flex justify-between items-center pb-8 z-50">
      <NavItem icon={<Home size={24} />} active={isActive('/home')} onClick={() => navigate('/home')} />
      <NavItem icon={<Search size={24} />} active={isActive('/explore')} onClick={() => {}} />
      <NavItem icon={<ShoppingBag size={24} />} active={isActive('/cart')} onClick={() => navigate('/cart')} />
      <NavItem icon={<User size={24} />} active={isActive('/profile')} onClick={() => {}} />
    </div>
  );
};

const NavItem = ({ icon, active, onClick }: { icon: React.ReactNode, active: boolean, onClick: () => void }) => (
  <button 
    onClick={onClick}
    className={`p-2 rounded-xl transition-colors ${active ? 'text-brand-purple bg-brand-purple/10' : 'text-gray-400'}`}
  >
    {icon}
  </button>
);

export default BottomNav;
