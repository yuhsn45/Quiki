# Quiki AI Strategy & Features

## 1. The "Celebration Assistant" (Chatbot & Recommendation)

### Functionality
A context-aware assistant that doesn't just list products but solves "gifting anxiety".

*   **Inputs**:
    *   *Who*: "My girlfriend" / "Boss" / "Toddler".
    *   *Occasion*: "Apology" / "Promotion" / "Just because".
    *   *Vibe*: "Classy" / "Fun" / "Over the top".
*   **AI Logic (Gemini/GPT)**:
    *   Maps "Apology" + "Girlfriend" -> High probability of Red Roses + Chocolate Cake + "I'm Sorry" card.
    *   Maps "Promotion" + "Boss" -> Premium Dry Fruit Hamper + Subtle Coffee Cake.

### Integration
*   **Floating Action Button (FAB)** on Home: "Ask AI for Ideas".
*   **Tech**: Python backend calling LLM API with prompt engineering focused on gifting etiquette.

## 2. Emotion-Driven UI

### Functionality
The app interface subtly shifts based on the user's detected intent.

*   **Detection**:
    *   User searches "Romantic cake" -> UI shifts to warmer pink/red gradients.
    *   User searches "Get well soon" -> UI shifts to calming greens/blues.
*   **Implementation**:
    *   Frontend state management (Redux/Context) holds a `currentMood` variable.
    *   Theme provider accepts `currentMood` to adjust CSS variables (gradients, accent colors).

## 3. Smart Reminder Engine

### Functionality
Proactive notification system that feels helpful, not spammy.

*   **Data Source**:
    *   User manual entry (Calendar).
    *   Social graph (if permissions granted).
    *   Past order history analysis (e.g., User ordered a cake on Oct 12 last year -> "Is [Name]'s birthday coming up again?").
*   **AI Logic**:
    *   Predicts relationship strength based on order value and frequency.
    *   Suggests gifts appropriate for the *current* year (e.g., "Last year you sent flowers, this year try this trending Pinata Cake").

## 4. Visual AI (AR & Quality Check)

### AR Preview
*   **Goal**: Reduce "expectation vs. reality" gap.
*   **Tech**: WebXR / ARKit. Projects the 3D model of the cake onto the user's table.

### Automated Quality Check (Partner App)
*   **Goal**: Ensure visual consistency.
*   **Flow**: Baker takes a photo of the finished cake before packing.
*   **AI Analysis**: Computer Vision model compares the photo against the reference image.
    *   *Checks*: Shape, Topping distribution, Text readability.
    *   *Action*: Rejects if similarity score < 80%.

## 5. Dynamic Pricing & Logistics

*   **Demand Prediction**: Machine Learning model forecasts demand surges (e.g., Valentine's Day evening, Mother's Day morning).
*   **Action**:
    *   Adjusts delivery fees dynamically.
    *   Pre-positions inventory (predictive dispatch) to "dark stores" closer to high-demand clusters.
