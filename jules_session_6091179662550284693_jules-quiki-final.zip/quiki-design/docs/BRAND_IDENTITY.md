# Quiki Brand Identity & Design System

## 1. Core Philosophy
**"Luxury Speed."**
The brand combines the immediacy of q-commerce with the premium feeling of a boutique patisserie. It shouldn't feel frantic (like Domino's tracker) but assured and elegant (like tracking an Uber Black).

## 2. Color Palette

| Color Name | Hex Code | Usage | Psychology |
| :--- | :--- | :--- | :--- |
| **Royal Purple** | `#6C5CE7` | Primary Brand, Buttons, Headers | Creativity, Wisdom, Luxury, Ambition. |
| **Golden Hour** | `#FFD700` | Accents, Stars, "Premium" tags | Wealth, Success, Celebration, Optimism. |
| **Cream Puff** | `#FFF8E7` | Backgrounds, Cards | Warmth, Comfort, Calmness (reduces eye strain). |
| **Pure White** | `#FFFFFF` | Text containers, High contrast areas | Cleanliness, Simplicity. |
| **Charcoal** | `#2D3436` | Primary Text | Readability, Softness (vs harsh black). |

## 3. Typography

*   **Headings**: *Product Sans* (or similar Rounded Sans).
    *   Friendly, modern, approachable but geometric.
*   **Body**: *SF Pro Text* (iOS) / *Roboto* (Android).
    *   Highly legible at small sizes.
*   **Scripts**: *Dancing Script* (Used sparingly for "Happy Birthday" or personalized notes).

## 4. Logo Concept

**Symbol**: A stylized "Q" that doubles as a stopwatch and a ribbon bow.
*   The tail of the "Q" is a motion streak (speed).
*   The loop of the "Q" forms a ribbon knot (gift/celebration).
*   **Style**: Minimalist line art, Gold gradient on Purple background.

**Wordmark**: "Quiki" in lower-case rounded sans-serif.
*   The dot on the "i"s can be replaced with tiny candle flames or hearts in festive modes.

## 5. UI Components

*   **Cards**: Large border-radius (16px-24px). Soft drop shadows (`0 4px 20px rgba(0,0,0,0.05)`).
*   **Buttons**:
    *   *Primary*: Royal Purple background, White text, rounded pills.
    *   *Secondary*: Cream background, Purple text.
    *   *Celebrate*: Gold gradient background, subtle pulse animation.
*   **Icons**:
    *   2D, outline style.
    *   Gold color when active, Grey when inactive.
    *   Slightly thicker stroke width (1.5px - 2px).

## 6. Tone of Voice
*   **Greetings**: "Ready to celebrate?" instead of "What do you want to order?"
*   **Errors**: "Oops, the cake crumbled! Let's try that again."
*   **Success**: "Yay! The party is on its way!"
