# Quiki UX Flows & Journey Maps

## 1. User Journey Maps

### A. The "Emergency Birthday" Buyer (Persona: Alex, 28, Forgot Partner's Birthday)
*   **Trigger**: Realizes it's 5 PM, partner comes home at 6 PM.
*   **Goal**: Get a premium cake and a gift delivered instantly.
*   **Flow**:
    1.  **Opens Quiki**: Splash screen loads fast.
    2.  **Home**: Sees "Quick Delivery (< 20 mins)" zone.
    3.  **Selection**: Filters by "Chocolate Truffle" (Partner's favorite, remembered by AI or manually selected).
    4.  **Product Page**: Views AR preview to ensure it looks good. Checks "Add-ons" -> Adds "I Love You" balloon and a Rose.
    5.  **Checkout**: One-tap payment (Apple Pay/UPI).
    6.  **Post-Order**: Watches live tracking.
    7.  **Delivery**: 18 minutes later, receives "Confetti" notification.
    8.  **Outcome**: Relief and Delight.

### B. The "Thoughtful Planner" (Persona: Priya, 34, Planning Mom's 60th)
*   **Trigger**: Notification "Mom's 60th Birthday is next week!".
*   **Goal**: Order a custom cake and schedule delivery.
*   **Flow**:
    1.  **Notification Click**: Deep links to "Gifts for Mom".
    2.  **Explore**: Browses "Luxury Tier" cakes.
    3.  **Customization**: Selects "Eggless", "Less Sugar", adds custom text "Happy 60th Ma".
    4.  **Video Message**: Records a 30s video greeting to be attached via QR code on the box.
    5.  **Schedule**: Selects date/time next week.
    6.  **Outcome**: Feeling organized and emotionally connected.

## 2. UI Flow Diagrams

### Core Purchase Flow

```mermaid
graph TD
    A[Splash Screen] -->|Auth/Guest| B[Home Screen]
    B -->|Search/Browse| C[Product Listing]
    B -->|Tap Product| D[Product Detail]
    C -->|Tap Product| D
    D -->|Add to Cart| E[Cart Drawer]
    E -->|Checkout| F[Payment Gateway]
    F -->|Success| G[Order Tracking]
    G -->|Delivered| H[Review & Reward]
```

### AI Personalization Flow

```mermaid
graph TD
    A[Onboarding] --> B{Ask User}
    B -->|Question 1| C[Who are you celebrating?]
    B -->|Question 2| D[Flavor Preferences?]
    B -->|Question 3| E[Important Dates?]
    C & D & E --> F[AI Profile Generation]
    F --> G[Customized Home Feed]
```

### Mood-Based Discovery Flow

```mermaid
graph TD
    A[Home Screen] --> B[Mood Selector]
    B -->|Romantic| C[Rose & Chocolate Feed]
    B -->|Apology| D[Flowers & 'Sorry' Cards]
    B -->|Celebration| E[Confetti & Party Packs]
    C & D & E --> F[Smart Suggestions]
```

## 3. Key Screen Interactions

*   **Splash**: Minimal logo animation. "Quiki" text fills with gold liquid.
*   **Home**:
    *   *Top*: "Good Evening, Alex. Celebrating someone today?"
    *   *Mid*: Horizontal scroll of "15-min delivery" cakes.
    *   *Bottom*: Mood bubbles (floating animations).
*   **Product Page**:
    *   *Hero*: 360-degree rotating cake view.
    *   *Action*: "Celebrate Now" button pulses gently.
*   **Tracking**:
    *   Map view with a custom scooter icon.
    *   Status updates are chat-bubble style: "Passing the park...", "Almost there!".
