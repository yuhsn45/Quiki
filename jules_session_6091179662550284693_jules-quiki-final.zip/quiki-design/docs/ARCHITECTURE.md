# Quiki Technical Architecture & System Design

## 1. High-Level Architecture

Quiki employs a microservices-based architecture to ensure scalability, speed, and reliability. The system is designed to handle high-concurrency traffic, especially during festive seasons, while maintaining low latency for the "15-minute delivery" promise.

### Tech Stack

*   **Frontend (Mobile App)**: React Native or Flutter. (Prototype will use React Web).
*   **Backend**: Node.js with Express/NestJS.
*   **Database**:
    *   **MongoDB**: For core data (Products, Users, Orders) due to its flexible schema and speed.
    *   **Redis**: For caching (Session management, real-time inventory, active carts).
*   **Real-time Engine**: Socket.io / Firebase Realtime Database (for live tracking and notifications).
*   **AI/ML**: Python (FastAPI) interacting with Gemini API / TensorFlow.
*   **Infrastructure**: AWS or Google Cloud Platform (GCP).
*   **Maps/Location**: Google Maps Platform (Routes, Distance Matrix, Geocoding).

## 2. System Components

### A. Client Application (User App)
*   **Identity Management**: OAuth (Google, Social), Phone OTP (Firebase Auth).
*   **Location Service**: GPS tracking, Geofencing for "Quick Delivery" zones.
*   **AR Module**: Unity integration or ARCore/ARKit for 3D Cake Preview.

### B. Partner Application (Bakery/Delivery)
*   **Order Management**: Real-time order acceptance/rejection.
*   **Inventory Sync**: Quick toggle for "Out of Stock".
*   **Delivery Routing**: Optimized path finding for delivery partners.

### C. Backend Services
*   **Order Service**: Handles cart, checkout, and payment processing.
*   **Catalog Service**: Manages products, categories, and inventory.
*   **User Service**: Profile, rewards, and history.
*   **Notification Service**: Push notifications, emails, SMS (Emotional triggers).
*   **AI Service**:
    *   *Recommendation Engine*: Personalized feeds.
    *   *Chatbot*: AI Celebration Assistant.
    *   *Dynamic Pricing*: Adjusts delivery fees based on demand/weather.

## 3. Database Schema (MongoDB)

### Users Collection
```json
{
  "_id": "ObjectId",
  "name": "String",
  "email": "String",
  "phone": "String",
  "preferences": {
    "flavors": ["Chocolate", "Red Velvet"],
    "dietary": ["Eggless"],
    "important_dates": [
      {"date": "2023-10-25", "relation": "Mother", "type": "Birthday"}
    ]
  },
  "loyalty_points": "Number",
  "saved_addresses": ["Array"]
}
```

### Products Collection
```json
{
  "_id": "ObjectId",
  "name": "String",
  "bakery_id": "ObjectId",
  "category": ["Cake", "Gift", "Mood:Romantic"],
  "price": "Number",
  "is_available": "Boolean",
  "preparation_time": "Number (mins)",
  "tags": ["Trending", "Best Seller"],
  "assets": {
    "images": ["Array"],
    "video": "URL",
    "ar_model": "URL"
  },
  "customization_options": ["Array"]
}
```

### Orders Collection
```json
{
  "_id": "ObjectId",
  "user_id": "ObjectId",
  "items": [
    {"product_id": "ObjectId", "quantity": 1, "customization": {}}
  ],
  "total_amount": "Number",
  "status": "Enum(PLACED, CONFIRMED, PREPARING, OUT_FOR_DELIVERY, DELIVERED)",
  "delivery_partner_id": "ObjectId",
  "eta": "Timestamp",
  "emotional_message": {
    "type": "Voice/Video",
    "url": "URL"
  }
}
```

## 4. API Structure (REST + GraphQL)

*   `POST /api/v1/auth/login`
*   `GET /api/v1/feed/home?lat=...&long=...` (Personalized Home Feed)
*   `GET /api/v1/products/search?q=...&mood=...`
*   `POST /api/v1/orders/checkout`
*   `GET /api/v1/tracking/:orderId` (WebSocket connection upgrade)

## 5. AI Integration Workflow

1.  **Data Ingestion**: User behavior (clicks, time spent), Order history, and Context (Time, Location, Weather).
2.  **Processing**: Gemini API analyzes "Mood" based on search queries (e.g., "sorry gift" -> suggests flowers/chocolates).
3.  **Output**: JSON response with ranked product IDs injected into the `/feed/home` endpoint.
